Rails.application.routes.draw do
  resources :appointments
	  devise_for :docters do
	    resources :appointments
	  end
	  devise_for :users do
	 	resources :appointments
	  end
  # For details on the DSL available within this file, see https://guides.rubyonrails.org/routing.html
      resources :home

      root to: "home#index"

end
