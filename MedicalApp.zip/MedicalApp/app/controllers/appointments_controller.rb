class AppointmentsController < ApplicationController
  #before_action :set_user
  def index
       @appointments = Appointment.all
  end
def new
    @appointment = Appointment.new
 end
 def show
  @docter = Docter.find(params[:id])
 @appointments = Appointment.where(docter_id: @docter.id)
 
 end
   def create
     
        @appointment = Appointment.new(appointment_params)
        if @appointment.save
      redirect_to appointments_path
        else
          render 'new' 
        end 
      
  end

  private
  def appointment_params
    params.require(:appointment).permit(:user_id,:docter_id,:atime)
  end

    def set_user
      @user = User.find(params[:id])
    end
end
