class Appointment < ApplicationRecord
	 validates :user_id,:docter_id,:atime, presence: true
	 validates_uniqueness_of :atime, :on => :create
	belongs_to :docter
	belongs_to :user


	 def time_in_between_9am_to_7pm
      errors.add(:atime , "between 9 to 7") if
       atime > 1 and atime < 12
  end
end
