class Docter < ApplicationRecord
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable, :trackable and :omniauthable
  has_many :users, through: :appointments
  has_many :appointments

  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable
end
