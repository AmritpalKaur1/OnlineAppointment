class AddSessionLimitableToDocters < ActiveRecord::Migration[6.0]
  def change
    add_column :docters, :unique_session_id, :string, limit: 20
  end
end
