class AddAdminToDocter < ActiveRecord::Migration[6.0]
  def change
    add_column :docters, :admin, :boolean , :default => true
    add_column :docters, :speciality, :string
    add_column :docters, :name, :string
  end
end
